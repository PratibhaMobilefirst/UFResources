import React, { useRef, useState, useEffect } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import html2canvas from 'html2canvas';
import { renderAsync } from 'docx-preview';
import Toolbar, { ToolType } from './Toolbar';
import PlaceholderPanel, { PlaceholderMeta } from './PlaceholderPanel';
import ThumbnailStrip from './ThumbnailStrip';
import PlaceholderExtension from './PlaceholderExtension';
// @ts-ignore: No types for mammoth
import mammoth from 'mammoth';
import Layout from '../Layout';
// import Underline from '@tiptap/extension-underline';
// @ts-ignore: No types for draggable
// import Draggable from '@tiptap/extension-draggable';
import BackArrow from "../../asset/img/Group 37878.svg"
import { useNavigate } from 'react-router-dom';
const A4_WIDTH = 794;
const A4_HEIGHT = 1100;

const DocumentEditor: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolType>('arrow');
  const [placeholders, setPlaceholders] = useState<PlaceholderMeta[]>([]);
  const [images, setImages] = useState<{ id: string; src: string; width?: number; height?: number }[]>([]);
  const [docTitle, setDocTitle] = useState('Untitled Document');
  const [docContent, setDocContent] = useState<string | null>(null);
  const [pages, setPages] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [pageThumbnails, setPageThumbnails] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const docxContainerRef = useRef<HTMLDivElement>(null);
  const [showInputBox, setShowInputBox] = useState(false);
  const [inputBoxValue, setInputBoxValue] = useState('');
  const [inputBoxPosition, setInputBoxPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useRef(() => window.history.back());
  const routerNavigate = useNavigate();
  // TipTap Editor
  const editor = useEditor({
    extensions: [
      StarterKit,
      Image,
      PlaceholderExtension,
    //   Underline,
    //   Draggable,
    ],
    content: '',
    onUpdate: ({ editor }) => {
      // Update placeholders on every change
      const phs: PlaceholderMeta[] = [];
      editor.state.doc.descendants((node, pos) => {
        if (node.type.name === 'placeholder') {
          phs.push({
            id: `${pos}-${node.attrs.value}`,
            value: node.attrs.value,
            page: 1, // TODO: Calculate page number if needed
            pos,
          });
        }
      });
      setPlaceholders(phs);
    },
  });

  // NOTE: TipTap does not have an official image resize extension. For resizing, use CSS or a custom extension if needed.

  // File loading (txt/docx)
  useEffect(() => {
    if (!file) return;
    setDocTitle(file.name);
    if (file.name.endsWith('.docx')) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const arrayBuffer = e.target?.result;
        if (arrayBuffer && arrayBuffer instanceof ArrayBuffer) {
          // Render docx visually using docx-preview
          if (docxContainerRef.current) {
            docxContainerRef.current.innerHTML = '';
            await renderAsync(arrayBuffer, docxContainerRef.current, undefined, {
              className: 'docx-preview',
              inWrapper: false,
            });
            // Each .docx page is rendered as a .docx-preview element
            const pageEls = Array.from(docxContainerRef.current.querySelectorAll('.docx-preview')) as HTMLElement[];
            const pageHtmls = pageEls.map(el => el.outerHTML);
            setPages(pageHtmls);
            setCurrentPage(0);
            setDocContent(pageHtmls[0] || '');
            if (editor) editor.commands.setContent(pageHtmls[0] || '');
            setTimeout(() => generatePageThumbnails(pageEls), 100);
          }
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result;
        const textContent = typeof result === 'string' ? result : '';
        setPages([textContent]);
        setCurrentPage(0);
        setDocContent(textContent);
        if (editor) editor.commands.setContent(textContent);
        setTimeout(() => generatePageThumbnails([textContent]), 100);
      };
      reader.readAsText(file);
    }
  }, [file, editor]);

  // Generate thumbnails for each page (from docx-preview elements)
  const generatePageThumbnails = async (pageEls: HTMLElement[] | string[]) => {
    const thumbnails: string[] = [];
    for (let i = 0; i < pageEls.length; i++) {
      let el: HTMLElement;
      if (typeof pageEls[i] === 'string') {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = pageEls[i] as string;
        tempDiv.style.width = '794px';
        tempDiv.style.height = '1123px';
        tempDiv.style.background = 'white';
        tempDiv.style.padding = '40px';
        tempDiv.style.overflow = 'hidden';
        document.body.appendChild(tempDiv);
        el = tempDiv;
      } else {
        el = pageEls[i] as HTMLElement;
      }
      try {
        const canvas = await html2canvas(el, { scale: 0.15, useCORS: true, logging: false });
        thumbnails.push(canvas.toDataURL('image/png'));
      } catch (error) {
        thumbnails.push('');
      }
      if (typeof pageEls[i] === 'string') {
        document.body.removeChild(el);
      }
    }
    setPageThumbnails(thumbnails);
  };

  // Tool actions
  const handleToolSelect = (tool: ToolType) => {
    setActiveTool(tool);
    if (editor) editor.commands.focus();
  };

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      const imageId = `img-${Date.now()}`;
      setImages((prev) => [...prev, { id: imageId, src: imageUrl, width: 300, height: 200 }]);
      if (editor) {
        editor.chain().focus().setImage({ src: imageUrl, width: 300, height: 200 }).run();
      }
    };
    reader.readAsDataURL(file);
  };

  // Placeholder edit/delete
  const handlePlaceholderEdit = (id: string, newValue: string) => {
    if (!editor) return;
    const ph = placeholders.find((p) => p.id === id);
    if (ph) {
      editor.chain().focus().setNodeSelection(ph.pos).updateAttributes('placeholder', { value: newValue }).run();
    }
  };
  const handlePlaceholderDelete = (id: string) => {
    if (!editor) return;
    const ph = placeholders.find((p) => p.id === id);
    if (ph) {
      editor.chain().focus().deleteRange({ from: ph.pos, to: ph.pos + 1 }).run();
    }
  };

  // File input
  const fileInputRef = useRef<HTMLInputElement>(null);
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setFile(file);
  };

  // Show input box at cursor for text/placeholder
  const showInputAtCursor = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const x = rect.left || window.innerWidth / 2;
    const y = rect.bottom || window.innerHeight / 2;
    setInputBoxPosition({ x, y: y + window.scrollY });
    setShowInputBox(true);
    setInputBoxValue('');
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
  };

  // Insert text or placeholder at cursor
  const handleEditorClick = (e: React.MouseEvent) => {
    if (!editor) return;
    if (activeTool === 'text' || activeTool === 'placeholder') {
      showInputAtCursor();
    }
  };

  // Handle input box submit
  const handleInputBoxSubmit = () => {
    if (!editor) return;
    if (inputBoxValue.trim()) {
      if (activeTool === 'text') {
        editor.chain().focus().insertContent(inputBoxValue).run();
      } else if (activeTool === 'placeholder') {
        editor.chain().focus().insertContent({ type: 'placeholder', attrs: { value: inputBoxValue } }).run();
      }
    }
    setShowInputBox(false);
    setInputBoxValue('');
  };

  // Placeholder auto-detect (stub: insert a sample placeholder)
  const handleAutoDetectPlaceholder = () => {
    if (!editor) return;
    // Get current content as HTML
    const html = editor.getHTML();
    // Find all {{...}} and [PLACEHOLDER] patterns
    const regex = /({{([^}]+)}}|\[([^[\]]+)\])/g;
    let match;
    let newContent = html;
    let offset = 0;
    const matches: { value: string; index: number; length: number }[] = [];
    while ((match = regex.exec(html)) !== null) {
      const value = match[2] || match[3] || 'Placeholder';
      matches.push({ value, index: match.index, length: match[0].length });
    }
    if (matches.length === 0) return;
    // Replace all matches with placeholder nodes using TipTap's insertContent
    let pos = 0;
    editor.commands.setContent(''); // Clear editor
    for (let i = 0; i < matches.length; i++) {
      const before = html.slice(pos, matches[i].index);
      if (before) editor.commands.insertContent(before);
      editor.commands.insertContent({ type: 'placeholder', attrs: { value: matches[i].value } });
      pos = matches[i].index + matches[i].length;
    }
    // Insert any remaining text
    if (pos < html.length) {
      editor.commands.insertContent(html.slice(pos));
    }
  };

  // Handle page change
  const handlePageSelect = (pageIdx: number) => {
    setCurrentPage(pageIdx);
    setDocContent(pages[pageIdx] || '');
    if (editor) editor.commands.setContent(pages[pageIdx] || '');
  };

  // Add image resize handler
  const handleImageResize = (id: string, width: number, height: number) => {
    setImages((prev) => prev.map(img => img.id === id ? { ...img, width, height } : img));
    if (editor) {
      // Update the image node in the editor (find by src)
      editor.commands.command(({ tr, state }) => {
        let updated = false;
        state.doc.descendants((node, pos) => {
          if (node.type.name === 'image' && node.attrs.src && node.attrs.src.includes(id)) {
            tr.setNodeMarkup(pos, undefined, { ...node.attrs, width, height });
            updated = true;
          }
        });
        if (updated) {
          editor.view.dispatch(tr);
        }
        return true;
      });
    }
  };

  return (
    <Layout>
    <div className="flex min-h-screen w-full bg-[#f8f9fa]">
      
      <div className="flex flex-col flex-1 w-full">

        {/* Header */}

        <div className="flex items-center justify-between bg-white border-b px-6 py-3">

          <div className="flex items-center gap-2">

            <button

              onClick={() => navigate.current()}

              className="hover:bg-gray-100 p-1 rounded"

            >

             <img src={BackArrow} className="w-5 h-5" />

            </button>

            <span className="font-semibold text-lg">Document Editor</span>

          </div>
             <Toolbar activeTool={activeTool} onToolSelect={setActiveTool} onImageUpload={handleImageUpload} />
 {/* Toolbar */}

          {/* <div className="flex gap-4 mb-4 mt-2 p-2">
  {TOOLBAR_OPTIONS.map((tool) => (
    <button
      key={tool.key}
      className={`w-10 h-10 rounded flex items-center justify-center border transition-colors ${
        activeTool === tool.key
          ? 'bg-blue-100 border-blue-700'
          : 'bg-white border-gray-200'
      }`}
      onClick={async () => {
        setActiveTool(tool.key);
        if (tool.key === 'text' && editor) {
          showInputAtCursor();
        } else if (tool.key === 'list' && editor) {
          showInputAtCursor();
        } else if (tool.key === 'image') {
          fileInputRef.current?.click();
          setIsImageUploading(true);
        }
      }}
      title={tool.key.charAt(0).toUpperCase() + tool.key.slice(1)}
    >
      {tool.icon ? (
        <tool.icon
          className={`w-5 h-5 ${
            activeTool === tool.key ? 'text-blue-900' : 'text-gray-700'
          }`}
        />
      ) : (
        <span
          className={`font-bold text-lg ${
            activeTool === tool.key ? 'text-blue-900' : 'text-gray-700'
          }`}
        >
          {tool.label}
        </span>
      )}
    </button>
  ))}
</div> */}

          <div className="flex gap-2">

           <div className="flex items-center bg-gray-200 rounded-full p-1 w-fit">
  <button
    className="bg-[#00426E] text-white px-4 py-1.5 rounded-full font-medium"
  >
    Edit Document
  </button>

  <button
    className="text-gray-700 px-4 py-1.5 rounded-full font-medium"
    // onClick={() => routerNavigate(/case/${id})}
  >
    Mark as Finished
  </button>
</div>

            <button className="bg-[#00426E] text-white px-4 py-2 rounded" 
            // onClick={() => routerNavigate(/case/${id})}
            >Save as Draft</button>

          </div>

        </div>
      {/* Hidden docx-preview container for rendering pages */}
      <div ref={docxContainerRef} style={{ display: 'none' }} />
      <div className="flex min-h-screen w-full bg-[#f8f9fa]">
      {/* Left Sidebar */}
      <div className="w-64 bg-white border-r flex flex-col">
        <div className="p-4 border-b">
          <div className="font-semibold text-sm mb-2">Case Name</div>
          <div className="text-base font-medium mb-4">Anderson Trust Creation</div>
          <div className="font-semibold text-sm mb-2">Documents</div>
          <div className="bg-[#E7F5FF] text-[#00426E] rounded px-3 py-2 font-medium mb-4 cursor-pointer">
            {docTitle}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept=".txt,.docx" onChange={handleFileChange} />
          <button className="bg-blue-100 text-blue-900 px-3 py-1 rounded" onClick={() => fileInputRef.current?.click()}>
            Upload Document
          </button>
        </div>
        {/* Clause List (example) */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="font-semibold text-sm mb-2">Clauses</div>
          <div className="mb-3 p-3 rounded border bg-white border-gray-200 cursor-pointer">
            <div className="font-semibold text-sm mb-1">Clause A</div>
            <div className="text-xs text-gray-600">Clause A content...</div>
          </div>
          {/* Add more clauses as needed */}
        </div>
      </div>
      {/* Main Editor */}
      <div className="flex-1 flex flex-col items-center bg-[#f8f9fa] relative">
     
        {/* Input Box Overlay for Text/Placeholder */}
        {showInputBox && (
          <div
            className="fixed z-50 bg-white shadow-lg rounded-lg border border-gray-200 p-2 flex items-center gap-2"
            style={{ left: inputBoxPosition.x, top: inputBoxPosition.y }}
            onClick={e => e.stopPropagation()}
          >
            <input
              ref={inputRef}
              type="text"
              value={inputBoxValue}
              onChange={e => setInputBoxValue(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') handleInputBoxSubmit();
                else if (e.key === 'Escape') setShowInputBox(false);
              }}
              className="border border-gray-300 rounded px-2 py-1 text-sm min-w-[200px]"
              autoFocus
            />
            <button
              onClick={handleInputBoxSubmit}
              className="p-1 hover:bg-green-50 rounded-full"
            >
              ✓
            </button>
            <button
              onClick={() => setShowInputBox(false)}
              className="p-1 hover:bg-red-50 rounded-full"
            >
              ✗
            </button>
          </div>
        )}
        {/* Scrollable multi-page editor */}
        <div className="overflow-y-auto w-full flex flex-col items-center gap-8 py-6" style={{ maxHeight: 'calc(100vh - 200px)' }}>
          {pages.map((pageHtml, idx) => (
            <div
              key={idx}
              className="bg-white p-8 rounded-lg shadow max-w-3xl w-full border border-gray-200 relative"
              style={{ minHeight: `${A4_HEIGHT / 1.5}px`, maxWidth: `${A4_WIDTH}px` }}
            >
              {/* Optional: Page number label */}
              <div className="absolute top-2 right-4 text-xs text-gray-400">Page {idx + 1}</div>
              {/* Render page content in TipTap EditorContent for the first page, or as HTML for others */}
              {editor && idx === 0 ? (
                <EditorContent editor={editor} />
              ) : (
                <div dangerouslySetInnerHTML={{ __html: pageHtml }} />
              )}
            </div>
          ))}
        </div>
        {/* Thumbnails at the bottom */}
        <div className="flex items-center justify-center w-full mt-4">
          {pageThumbnails.map((thumbnail, idx) => (
            <div
              key={idx}
              className={`w-24 h-16 mx-1 border rounded cursor-pointer bg-white shadow-sm flex flex-col items-center justify-center`}
            >
              {thumbnail ? (
                <img src={thumbnail} alt={`Page ${idx + 1}`} className="w-full h-full object-cover rounded" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">No Preview</div>
              )}
              <div className="text-center text-xs text-gray-600">{idx + 1}</div>
            </div>
          ))}
        </div>
      </div>
      {/* Right Sidebar */}
      <div className="w-72 bg-white border-l flex flex-col p-4">
        <div className="font-semibold mb-4">Images</div>
        {images.length === 0 && <div className="text-gray-400 text-sm mb-4">No images added yet.</div>}
        {images.map((img) => (
          <div key={img.id} className="mb-4 p-2 bg-gray-50 rounded border flex flex-col items-center">
            <img src={img.src} alt="Inserted" className="w-20 h-20 object-contain mb-2 border" style={{ width: img.width, height: img.height }} />
            <div className="text-xs text-gray-600 mb-1">Image</div>
            <div className="flex gap-2 items-center mb-1">
              <label className="text-xs">W:</label>
              <input type="number" value={img.width || 100} min={50} max={800} className="w-12 border rounded px-1 text-xs" onChange={e => handleImageResize(img.id, Number(e.target.value), img.height || 100)} />
              <label className="text-xs">H:</label>
              <input type="number" value={img.height || 100} min={50} max={1123} className="w-12 border rounded px-1 text-xs" onChange={e => handleImageResize(img.id, img.width || 100, Number(e.target.value))} />
            </div>
          </div>
        ))}
        <div className="font-semibold mb-4 mt-6">Placeholders</div>
        <button
          className="mb-4 bg-blue-100 text-blue-900 px-3 py-1 rounded"
          onClick={handleAutoDetectPlaceholder}
        >
          Auto-Detect Placeholder
        </button>
        <PlaceholderPanel
          placeholders={placeholders}
          onEdit={handlePlaceholderEdit}
          onDelete={handlePlaceholderDelete}
        />
      </div>
      </div>
    </div>
    </div>
    </Layout>
  );
};

export default DocumentEditor; 





// // ... existing imports ...
// import React, { useRef, useState, useEffect } from 'react';
// // ... previous imports ...

// const DocumentEditor: React.FC = () => {
//   // ... existing state ...
//   const [activeTool, setActiveTool] = useState<ToolType>('arrow');
//   const [showInputBox, setShowInputBox] = useState(false);
//   const [inputBoxValue, setInputBoxValue] = useState('');
//   const [inputBoxPosition, setInputBoxPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
//   const inputRef = useRef<HTMLInputElement>(null);
//   // ... rest of state ...

//   // ... editor setup ...

//   // Show input box at cursor for text/placeholder
//   const showInputAtCursor = () => {
//     const selection = window.getSelection();
//     if (!selection || selection.rangeCount === 0) return;
//     const range = selection.getRangeAt(0);
//     const rect = range.getBoundingClientRect();
//     const x = rect.left || window.innerWidth / 2;
//     const y = rect.bottom || window.innerHeight / 2;
//     setInputBoxPosition({ x, y: y + window.scrollY });
//     setShowInputBox(true);
//     setInputBoxValue('');
//     setTimeout(() => {
//       inputRef.current?.focus();
//     }, 0);
//   };

//   // Insert text or placeholder at cursor
//   const handleEditorClick = (e: React.MouseEvent) => {
//     if (!editor) return;
//     if (activeTool === 'text' || activeTool === 'placeholder') {
//       showInputAtCursor();
//     }
//   };

//   // Handle input box submit
//   const handleInputBoxSubmit = () => {
//     if (!editor) return;
//     if (inputBoxValue.trim()) {
//       if (activeTool === 'text') {
//         editor.chain().focus().insertContent(inputBoxValue).run();
//       } else if (activeTool === 'placeholder') {
//         editor.chain().focus().insertContent({ type: 'placeholder', attrs: { value: inputBoxValue } }).run();
//       }
//     }
//     setShowInputBox(false);
//     setInputBoxValue('');
//   };

//   // Placeholder auto-detect (stub: insert a sample placeholder)
//   const handleAutoDetectPlaceholder = () => {
//     if (!editor) return;
//     editor.chain().focus().insertContent({ type: 'placeholder', attrs: { value: 'Auto-Detected Placeholder' } }).run();
//   };

//   // ... rest of the code ...

//   return (
//     <div className="flex min-h-screen w-full bg-[#f8f9fa]">
//       {/* ... left sidebar ... */}
//       <div className="flex-1 flex flex-col items-center bg-[#f8f9fa] relative">
//         <Toolbar activeTool={activeTool} onToolSelect={setActiveTool} onImageUpload={handleImageUpload} />
//         {/* Input Box Overlay for Text/Placeholder */}
//         {showInputBox && (
//           <div
//             className="fixed z-50 bg-white shadow-lg rounded-lg border border-gray-200 p-2 flex items-center gap-2"
//             style={{ left: inputBoxPosition.x, top: inputBoxPosition.y }}
//             onClick={e => e.stopPropagation()}
//           >
//             <input
//               ref={inputRef}
//               type="text"
//               value={inputBoxValue}
//               onChange={e => setInputBoxValue(e.target.value)}
//               onKeyDown={e => {
//                 if (e.key === 'Enter') handleInputBoxSubmit();
//                 else if (e.key === 'Escape') setShowInputBox(false);
//               }}
//               className="border border-gray-300 rounded px-2 py-1 text-sm min-w-[200px]"
//               autoFocus
//             />
//             <button
//               onClick={handleInputBoxSubmit}
//               className="p-1 hover:bg-green-50 rounded-full"
//             >
//               ✓
//             </button>
//             <button
//               onClick={() => setShowInputBox(false)}
//               className="p-1 hover:bg-red-50 rounded-full"
//             >
//               ✗
//             </button>
//           </div>
//         )}
//         <div
//           className="prose bg-white p-6 rounded-lg shadow max-w-3xl w-full min-h-[400px] mt-4"
//           style={{ minHeight: `${A4_HEIGHT / 2}px`, maxWidth: `${A4_WIDTH}px` }}
//           onClick={handleEditorClick}
//         >
//           {editor && <EditorContent editor={editor} />}
//         </div>
//         <ThumbnailStrip thumbnails={pageThumbnails} currentPage={currentPage} onPageSelect={handlePageSelect} />
//       </div>
//       {/* Right Sidebar: Placeholder Panel with Auto-Detect */}
//       <div className="w-72 bg-white border-l flex flex-col p-4">
//         <div className="font-semibold mb-4">Placeholders</div>
//         <button
//           className="mb-4 bg-blue-100 text-blue-900 px-3 py-1 rounded"
//           onClick={handleAutoDetectPlaceholder}
//         >
//           Auto-Detect Placeholder
//         </button>
//         <PlaceholderPanel
//           placeholders={placeholders}
//           onEdit={handlePlaceholderEdit}
//           onDelete={handlePlaceholderDelete}
//         />
//       </div>
//     </div>
//   );
// };
